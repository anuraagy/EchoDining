var Protocol = require("./protocol");
var protocol = new Protocol("11-10-2016");
protocol.getVegetarian("Lunch", "Wiley", function(speechOutput) {
  console.log(speechOutput)
});
